# nodejs-demoapp
A demo app prepared to get started with Node.js
